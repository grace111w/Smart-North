import React from "react";
import {
  StyleSheet,
  View,
  TextInput,
  style,
  Button,
  SafeAreaView,
} from "react-native";

